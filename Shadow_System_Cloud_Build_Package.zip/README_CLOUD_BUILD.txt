SHADOW SYSTEM — PHONE-ONLY CLOUD BUILD

This package is built in GitHub Actions (GitHub's cloud build service).

IMPORTANT: The Android project is inside the ZIP. Upload this ZIP file to a new GitHub repository. Then create the workflow file shown in CLOUD_WORKFLOW.yml at this exact path:
.github/workflows/android-apk.yml

After saving the workflow, open the repository's Actions tab. The workflow will run and build a debug APK. When it finishes successfully, open the run, scroll to Artifacts, and download shadow-system-debug-apk. Extract the downloaded artifact ZIP and tap the APK to install it. You may need to allow installs from your browser/files app.

GitHub account required. GitHub Actions has usage limits; public repositories generally have free standard-runner minutes. Do not add passwords, signing keys, or private information to the repository.
