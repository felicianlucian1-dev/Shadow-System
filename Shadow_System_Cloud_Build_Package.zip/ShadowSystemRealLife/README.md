# SHADOW SYSTEM — Real Life Edition (Android)

A native Android Studio starter project for a Solo Leveling-inspired personal development RPG.

## Features
- Player level, XP bar, and E-to-S rank
- Main quests and optional side quests across trading discipline, learning, relationships, fitness, faith and daily discipline
- Scripture prompt, XP awards and local progress persistence
- Accountability points and streak reset when a missed quest is recorded
- Blue holographic visual theme
- Android text-to-speech System voice with a low-pitched, slower delivery using the device's installed TTS voice
- Daily wake-up announcement, defaulting to 06:00 and repeating every day
- Custom wake-up time, voice on/off switch, and a test-voice button
- Scheduled notification and alarm restoration after device reboot

## Build and run
1. Install Android Studio.
2. Open this project folder.
3. Allow Gradle sync.
4. Connect an Android phone with USB debugging enabled or use an emulator.
5. Press Run.
6. On first launch, allow notifications. The daily voice wake-up is enabled by default for 06:00.
7. In the System Voice / Wake-up panel, choose your preferred time and use **TEST SYSTEM VOICE**.
8. On Android 12 and newer, tap **ALLOW PRECISE WAKE-UP** and grant the special alarm permission for the most accurate schedule.

## Important Android behaviour
- The daily announcement is scheduled to work while the app is not open. The phone must be powered on, the app must not be force-stopped, notifications must be allowed, and media/notification volume must be audible.
- If exact-alarm access is denied, Android may deliver the alarm later than the selected time. Battery restrictions and Do Not Disturb can also affect delivery or audibility.
- The spoken voice uses Android's installed Text-to-Speech engine. The exact voice depends on the voice/language packs installed on the phone; this starter does not generate a custom anime voice.
- The wake-up alarm and notification are implemented. This is not yet a conversational AI voice assistant; live two-way AI conversation requires speech recognition and an AI service/backend.

## Prototype limitations
- Quest completion flags reset when the app is restarted; XP and level are persisted.
- Daily quest generation, custom mission creation, calendar, cloud sync, and AI-generated quests are not yet implemented.
- The system does not verify task completion; the player marks missions complete honestly.

## Safety and design principles
- No fixed daily trading profit targets. Markets are uncertain; missions reward process, risk management and journaling, not profits.
- Relationship missions focus on mutual respect and communication, not targeting a specific person.
- Missed quests use mild accountability, not dangerous physical punishments, deprivation, humiliation or financial penalties.
- XP is a motivational game mechanic, not a measure of personal worth.
