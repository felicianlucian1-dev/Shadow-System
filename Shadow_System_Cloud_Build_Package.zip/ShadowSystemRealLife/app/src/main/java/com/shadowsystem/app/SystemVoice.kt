package com.shadowsystem.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Calendar
import java.util.Locale

object SystemVoice {
    const val PREFS = "shadow_system"
    const val CHANNEL_ID = "shadow_system_quests"
    const val ACTION_WAKE = "com.shadowsystem.app.ACTION_DAILY_WAKE"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "System quest alerts", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Daily wake-up and Shadow System mission announcements" }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun schedule(context: Context, hour: Int, minute: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt("wake_hour", hour).putInt("wake_minute", minute).putBoolean("voice_enabled", true).apply()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, DailyWakeReceiver::class.java).setAction(ACTION_WAKE)
        val pending = PendingIntent.getBroadcast(
            context, 701, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
        }
    }

    fun cancel(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("voice_enabled", false).apply()
        val intent = Intent(context, DailyWakeReceiver::class.java).setAction(ACTION_WAKE)
        val pending = PendingIntent.getBroadcast(
            context, 701, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }
}

class DailyWakeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences(SystemVoice.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("voice_enabled", false)) return

        // Schedule tomorrow's announcement before doing any speech work.
        SystemVoice.scheduleTomorrow(context, prefs.getInt("wake_hour", 6), prefs.getInt("wake_minute", 0))
        SystemVoice.createChannel(context)
        val notification = android.app.Notification.Builder(context, SystemVoice.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("SHADOW SYSTEM — DAILY QUEST")
            .setContentText("PLAYER! WAKE UP. YOUR DAILY QUEST IS WAITING.")
            .setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(
                context, 702, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ))
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(702, notification)

        val pendingResult = goAsync()
        lateinit var speech: TextToSpeech
        speech = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                speech.language = Locale.getDefault()
                speech.setSpeechRate(0.88f)
                speech.setPitch(0.82f)
                speech.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) {
                        speech.shutdown()
                        pendingResult.finish()
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        speech.shutdown()
                        pendingResult.finish()
                    }
                })
                speech.speak(
                    "Player! Wake up. Your daily quest is waiting. Rise and become stronger today.",
                    TextToSpeech.QUEUE_FLUSH, null, "shadow_daily_wake"
                )
            } else {
                speech.shutdown()
                pendingResult.finish()
            }
        }
    }
}

private fun SystemVoice.scheduleTomorrow(context: Context, hour: Int, minute: Int) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, DailyWakeReceiver::class.java).setAction(SystemVoice.ACTION_WAKE)
    val pending = PendingIntent.getBroadcast(
        context, 701, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val next = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, 1)
        set(Calendar.HOUR_OF_DAY, hour)
        set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
    } else {
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences(SystemVoice.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean("voice_enabled", false)) {
            SystemVoice.schedule(context, prefs.getInt("wake_hour", 6), prefs.getInt("wake_minute", 0))
        }
    }
}
