package com.shadowsystem.app

import android.os.Bundle
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.app.TimePickerDialog
import android.os.Build
import android.provider.Settings
import android.net.Uri
import android.app.AlarmManager
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BG = Color(0xFF030914)
private val PANEL = Color(0xFF071A2D)
private val CYAN = Color(0xFF35C8FF)
private val MUTED = Color(0xFF8BAFC5)
private val PALE = Color(0xFFE7F8FF)

data class Mission(
    val id: Int, val category: String, val title: String,
    val instruction: String, val reward: Int, val isSide: Boolean = false,
    val done: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("shadow_system", MODE_PRIVATE)
        SystemVoice.createChannel(this)
        if (!prefs.contains("voice_enabled")) {
            // The player explicitly requested an automatic daily wake-up: default to 06:00.
            SystemVoice.schedule(this, 6, 0)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 901)
        }
        setContent {
            var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
            var level by remember { mutableIntStateOf(prefs.getInt("level", 1)) }
            var streak by remember { mutableIntStateOf(prefs.getInt("streak", 0)) }
            var penaltyPoints by remember { mutableIntStateOf(prefs.getInt("penalties", 0)) }
            var missions by remember {
                mutableStateOf(listOf(
                    Mission(1, "TRADING", "Trade like a professional", "Before any trade, mark your setup, entry, stop-loss and risk. If there is no valid setup, do not trade. Finish by writing one journal note.", 40),
                    Mission(2, "KNOWLEDGE", "Upgrade your mind", "Study one useful topic for 30 minutes. Write down three things you learned.", 30),
                    Mission(3, "RELATIONSHIPS", "Build real connection", "Practise confident, respectful conversation. Listen well; do not pressure anyone or treat a relationship like a prize.", 30),
                    Mission(4, "DISCIPLINE", "Keep your word", "Complete your most important responsibility before entertainment.", 25),
                    Mission(5, "BODY", "Train your body", "Do a safe workout suited to your fitness level, then recover and hydrate.", 30),
                    Mission(6, "FAITH", "Wisdom for today", "Read Proverbs 16:3. Reflect on committing your plans to God and acting with integrity.", 20),
                    Mission(7, "TRADING", "Side mission: market replay", "Spend 15 minutes reviewing a historical chart. No live trade is required.", 15, true),
                    Mission(8, "SOCIAL", "Side mission: confidence", "Start one friendly conversation and focus on being present, not impressing someone.", 15, true),
                    Mission(9, "LEARNING", "Side mission: skill practice", "Practise a useful skill for 20 minutes and record what improved.", 20, true)
                ))
            }
            fun persist() {
                prefs.edit().putInt("xp", xp).putInt("level", level)
                    .putInt("streak", streak).putInt("penalties", penaltyPoints).apply()
            }
            fun finish(m: Mission) {
                if (!m.done) {
                    missions = missions.map { if (it.id == m.id) it.copy(done = true) else it }
                    xp += m.reward
                    while (xp >= level * 100) { xp -= level * 100; level++ }
                    persist()
                }
            }
            fun applyPenalty() {
                // Gentle accountability: no dangerous punishments and no loss of earned levels.
                penaltyPoints += 1
                streak = 0
                persist()
            }
            MaterialTheme(colorScheme = darkColorScheme(
                background = BG, surface = PANEL, primary = CYAN,
                onBackground = PALE, onSurface = PALE
            )) {
                SystemHome(level, xp, streak, penaltyPoints, missions, ::finish, ::applyPenalty, this@MainActivity)
            }
        }
    }
}

@Composable
fun SystemHome(
    level: Int, xp: Int, streak: Int, penaltyPoints: Int,
    missions: List<Mission>, onFinish: (Mission) -> Unit, onPenalty: () -> Unit, context: Context
) {
    val threshold = level * 100
    val progress = (xp.toFloat() / threshold).coerceIn(0f, 1f)
    val main = missions.filter { !it.isSide }
    val side = missions.filter { it.isSide }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(BG),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SYSTEM ONLINE  •  REAL LIFE MODE", color = CYAN, fontSize = 11.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(7.dp))
                Text("SHADOW SYSTEM", color = PALE, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("PLAYER: FELICIAN", color = MUTED, fontSize = 12.sp, letterSpacing = 2.sp)
            }
        }
        item {
            PanelCard("PLAYER STATUS") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    BigStat("LEVEL", level.toString())
                    BigStat("RANK", rank(level))
                    BigStat("STREAK", streak.toString())
                }
                Spacer(Modifier.height(13.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("EXPERIENCE", color = MUTED, fontSize = 11.sp)
                    Text("$xp / $threshold XP", color = CYAN, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().padding(top = 7.dp).height(8.dp),
                    color = CYAN, trackColor = Color(0xFF18354A)
                )
            }
        }
        item {
            PanelCard("SYSTEM DIRECTIVE") {
                Text("Become capable, disciplined, wise and financially responsible. Every mission should move your real life forward.", color = PALE, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text("TODAY'S SCRIPTURE", color = CYAN, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Proverbs 16:3 — Commit your work to the Lord; make plans with purpose and act faithfully.", color = MUTED, fontSize = 12.sp)
            }
        }
        item { SystemVoicePanel(context) }
        item { SectionHeader("MAIN QUESTS", "Complete important missions to earn XP") }
        items(main, key = { it.id }) { m -> MissionCard(m, onFinish) }
        item { SectionHeader("SIDE QUESTS", "Optional missions for bonus XP") }
        items(side, key = { it.id }) { m -> MissionCard(m, onFinish) }
        item {
            PanelCard("ACCOUNTABILITY / PENALTY") {
                Text("Missed a quest? Record it honestly. Your penalty is a reset of your current streak and one accountability point — not losing levels or being pushed into unsafe behaviour.", color = MUTED, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("ACCOUNTABILITY POINTS: $penaltyPoints", color = CYAN, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onPenalty, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PALE)) {
                    Text("RECORD A MISSED QUEST")
                }
            }
        }
        item {
            PanelCard("SYSTEM RULES") {
                Rule("Trading", "No daily profit quota. Protect capital, use a written risk limit, and accept no-trade days. Never borrow or increase risk to chase XP.")
                Rule("Relationships", "The System can coach confidence and kindness, but cannot assign a real person's Instagram account or tell you to propose. Proposals belong in a mutual, established relationship.")
                Rule("Growth", "XP rewards completed effort and honest reflection, not money earned, romantic attention, or physical appearance.")
            }
        }
        item {
            Text("SYSTEM MESSAGE: Your level is a game mechanic. Real growth comes from consistent actions, sound judgement and respect.", color = MUTED, fontSize = 10.sp)
            Text("RISE THROUGH YOUR ACTIONS, PLAYER.", color = CYAN, fontSize = 11.sp, letterSpacing = 2.sp,
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp))
        }
    }
}

@Composable
fun PanelCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().border(1.dp, CYAN.copy(alpha = .65f), RoundedCornerShape(8.dp))
        .background(PANEL, RoundedCornerShape(8.dp)).padding(14.dp)) {
        Text("◇  $title", color = CYAN, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
fun BigStat(label: String, value: String) {
    Column {
        Text(label, color = MUTED, fontSize = 9.sp)
        Text(value, color = PALE, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = CYAN, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp)
        Text(subtitle, color = MUTED, fontSize = 10.sp)
    }
}

@Composable
fun MissionCard(m: Mission, onFinish: (Mission) -> Unit) {
    PanelCard(if (m.done) "MISSION CLEARED ✓" else "${m.category}  •  ${if (m.isSide) "SIDE QUEST" else "MAIN QUEST"}") {
        Text(m.title, color = PALE, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(5.dp))
        Text(m.instruction, color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("+${m.reward} XP", color = CYAN, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            if (m.done) Text("COMPLETED", color = Color(0xFF63E6A5), fontSize = 10.sp)
            else Button(onClick = { onFinish(m) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0B4566), contentColor = PALE),
                shape = RoundedCornerShape(6.dp)) { Text("CLEAR QUEST", fontSize = 10.sp) }
        }
    }
}

@Composable
fun Rule(title: String, body: String) {
    Text(title, color = CYAN, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Text(body, color = MUTED, fontSize = 11.sp)
    Spacer(Modifier.height(8.dp))
}

fun rank(level: Int) = when {
    level >= 50 -> "S"
    level >= 35 -> "A"
    level >= 25 -> "B"
    level >= 15 -> "C"
    level >= 8 -> "D"
    else -> "E"
}


@Composable
fun SystemVoicePanel(context: Context) {
    val prefs = remember { context.getSharedPreferences(SystemVoice.PREFS, Context.MODE_PRIVATE) }
    var enabled by remember { mutableStateOf(prefs.getBoolean("voice_enabled", false)) }
    var hour by remember { mutableIntStateOf(prefs.getInt("wake_hour", 6)) }
    var minute by remember { mutableIntStateOf(prefs.getInt("wake_minute", 0)) }
    val timeLabel = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)

    PanelCard("SYSTEM VOICE / WAKE-UP") {
        Text("The System can announce your daily quest even when the app is closed. Your phone must be on, notifications allowed and not muted.", color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("DAILY VOICE ANNOUNCEMENT", color = PALE, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(if (enabled) "ACTIVE • EVERY DAY" else "DISABLED", color = if (enabled) CYAN else MUTED, fontSize = 10.sp)
            }
            Switch(checked = enabled, onCheckedChange = { checked ->
                enabled = checked
                if (checked) SystemVoice.schedule(context, hour, minute) else SystemVoice.cancel(context)
            })
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = {
            TimePickerDialog(context, { _, h, m ->
                hour = h
                minute = m
                if (enabled) SystemVoice.schedule(context, h, m)
                else prefs.edit().putInt("wake_hour", h).putInt("wake_minute", m).apply()
            }, hour, minute, true).show()
        }, modifier = Modifier.fillMaxWidth()) {
            Text("WAKE-UP TIME: $timeLabel", color = PALE)
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = {
            speakSystemTest(context, "Player! The System is online. Your path to greatness begins now.")
        }, modifier = Modifier.fillMaxWidth()) {
            Text("TEST SYSTEM VOICE", color = CYAN)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            OutlinedButton(onClick = {
                context.startActivity(android.content.Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:${context.packageName}")))
            }, modifier = Modifier.fillMaxWidth()) {
                Text("ALLOW PRECISE WAKE-UP", color = CYAN)
            }
        }
        Text("Note: Android may deliver an inexact alarm if exact-alarm access is not allowed. Battery saver and Do Not Disturb can also affect announcements.", color = MUTED, fontSize = 10.sp)
    }
}


private fun speakSystemTest(context: Context, message: String) {
    lateinit var engine: TextToSpeech
    engine = TextToSpeech(context.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
            engine.language = Locale.getDefault()
            engine.setSpeechRate(0.88f)
            engine.setPitch(0.82f)
            engine.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) { engine.shutdown() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { engine.shutdown() }
            })
            engine.speak(message, TextToSpeech.QUEUE_FLUSH, null, "shadow_voice_test")
        } else {
            engine.shutdown()
        }
    }
}
